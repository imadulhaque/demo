(function(){

  angular
       .module('dashboard')
       .controller('dashboardController', [
          'dashboardService', 'vsphereService', '$location','$state',
           DashboardController
       ]);

  /**
   * Main Controller for the Angular Material Starter App
   * @param $scope
   * @param $mdSidenav
   * @param avatarsService
   * @constructor
   */
  function DashboardController(dashboardService, vsphereService, $location, $state) {
    var self = this;

    self.logout = logout;
    self.getHostInfo = getHostInfo;
    self.menus  = [];
    self.selectedMenu     = null;
    self.selectMenu   = selectMenu;
    self.toggleMenuList   = toggleMenuList;
    self.hostInfo = {name: "host", title: "Host", list:[]};
    self.dataStores = {name: "datastore", title: "Datastores", list:[]};
    self.vms = {name: "virtualMachine", title: "Virtual Machines", list:[]};
    self.resourcePools = {name: "resourcePools", title: "Resource Pools", list:[]};

    // Load all menus on side bar
    dashboardService
      .loadMenus()
      .then( function(menus) {
          self.menus    = menus;
          self.selectedMenu = menus[0];
      });

    // Get host Info
    self.getHostInfo();

    // Go to host page under home
    $state.go('home.host');
      
    // *********************************
    // Internal methods
    // *********************************
    /**
    * Hide or Show the 'left' sideNav area
    */
    function logout() {
        vsphereService.logout()
            .then( function() {
                $location.url('/login');
        },
        function(err) {
            $location.url('/login');
        });
    }
    /**
    * Hide or Show the 'left' sideNav area
    */
    function getHostInfo(){
        vsphereService.getHostInfo()
        .then(function(items) {
            // get host name info
            self.hostInfo.list = _.chain(items)
                .filter(function(item){
                    if (item.obj.type === 'HostSystem'){
                        return item.propSet;
                    }
                })
                .map(function(item){
                    return item.propSet;
                })
                .flatten()
                .value();
            self.hostInfo.list.push({name:'hostname', val: vsphereService.getKey()});

            // get datastores
            self.dataStores.list = _.chain(items)
                .filter(function(item){
                    if (item.obj.type === 'Datastore'){
                        return item.propSet;
                    }
                })
                .map(function(item){
                    return item.propSet;
                })
                .flatten()
                .value();

            // get vms
            self.vms.list = _.chain(items)
                .filter(function(item){
                    if (item.obj.type === 'VirtualMachine'){
                        return item.propSet;
                    }
                })
                .map(function(item){
                    return item.propSet;
                })
                .flatten()
                .value();

            // get resource pools
            self.resourcePools.list = _.chain(items)
                .filter(function(item){
                    if (item.obj.type === 'ResourcePool'){
                        return item.propSet;
                    }
                })
                .map(function(item){
                    return item.propSet;
                })
                .flatten()
                .value();
        },
        function(err) {
            
        });
    }

    /**
    * Hide or Show the 'left' sideNav area
    */
    function toggleMenuList() {
      $mdSidenav('left').toggle();
    }
    /**
    * Select the current menu
    * @param menu
    */
    function selectMenu (menu) {
      self.selectedMenu = angular.isNumber(menu.key) ? $scope.menus[menu.key] : menu;
      self.toggleMenuList();
    }
  }

})();
