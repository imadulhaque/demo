/**
 * Created by ahaq on 7/20/2016.
 */
var express  = require('express');

var httpProxy = require("http-proxy");
var http = require("http");
var https = require("https");
var bodyParser = require('body-parser');    // pull information from HTML POST (express4)
var methodOverride = require('method-override'); // simulate DELETE and PUT (express4)
var path = require("path");
var fs = require("fs");

var app = express();

var proxy = httpProxy.createProxyServer({
    secure: false
});
proxy.on("error", function(err, req, res) {
    res.status(500).end();
});

app.use(function(req, res, next) {
    if ((/xsd|wsdl/.test(req.url) || /post/i.test(req.method))) {
        req.url = req.originalUrl;
        proxy.web(req, res, {
            target: req.headers["vsphere-target"]
        });
    } else {
        return next();
    }
});
// configuration =================
app.use(express.static(__dirname + './../app'));                // set the static files location /public/img will be /img for users
app.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
app.use(bodyParser.json());                                     // parse application/json
app.use(bodyParser.json({ type: 'application/vnd.api+json' })); // parse application/vnd.api+json as json
app.use(methodOverride());

// Avoids DEPTH_ZERO_SELF_SIGNED_CERT error for self-signed certs
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

var options = {
    pfx: fs.readFileSync(path.join(__dirname, "./cert/sample.pfx"))
};

// listen (start app with node server.js) ======================================
https.createServer(options, app).listen(4445);
console.log("App listening on port 4445");
