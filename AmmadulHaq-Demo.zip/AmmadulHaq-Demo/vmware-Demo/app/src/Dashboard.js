(function(){
  'use strict';

  // Prepare the 'dashboard' modules for subsequent registration of controllers and delegates
  angular.module('dashboard', [ 'ngMaterial' ]);
})();
