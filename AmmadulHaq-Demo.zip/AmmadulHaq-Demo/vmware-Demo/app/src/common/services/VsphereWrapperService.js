/**
 * Created by ahaq on 7/24/2016.
 */

(function() {
    'use strict';

    angular.module('dashboard')
        .service('vsphereService', ['$q', '$cookies', VsphereService]);

    /**
     * vsphere DataService
     *
     * @returns {{login: Function}}
     * @constructor
     */
    function VsphereService($q, $cookies) {
        var cookieKey = "hostname";
        var cookie = getCookie(cookieKey);
        var service;
        var serviceOptions = {
            proxy: true
        };

        /**
         * Get cookie
         */
        function getCookie(name) {
            var match = $cookies.get(name);
            return match || undefined;
        }

        /**
         * Set cookie
         */
        function setCookie(name, value) {
            $cookies.put(name, value !== undefined ? value : undefined);
        }

        /**
         * Remove cookie
         */
        function removeCookie(name) {
            $cookies.remove(name);
        }

        /**
         * Clean up
         */
        function cleanup(){
            removeCookie(cookieKey);
            cookie = undefined;
            service = undefined;
        }
        // Promise-based APIs
        return {
            /**
             * login
             */
            getKey: function(){
                return cookie;
            } ,
            /**
             * login
             */
            login: function (hostname, username, password) {
                var deferred = $q.defer();
                if (cookie === undefined && service === undefined) {
                    vsphere.vimService(hostname, serviceOptions).then(function (vimService) {
                        service = vimService;
                        service.vimPort.login(service.serviceContent.sessionManager,
                            username, password).then(function () {
                            cookie = hostname;
                            setCookie(cookieKey, cookie);
                            console.log("logged in to " + cookie);
                            deferred.resolve();
                        }, function (err) {
                            console.log(err + " " + err.message);
                            deferred.reject(err);
                        });
                    }, function (err) {
                        console.log(err + " " + err.message);
                        deferred.reject(err);
                    });
                }
                else {
                    deferred.resolve();
                }
                return deferred.promise;
            },
            /**
             * Check if user is already logged in
             */
            loggedin: function () {
                var deferred = $q.defer();

                if (cookie !== undefined && service !== undefined) {
                    deferred.resolve(true);
                }
                else if (cookie !== undefined){
                     vsphere.vimService(cookie, serviceOptions)
                        .then(function (vimService) {
                            service = vimService;
                            deferred.resolve(true);
                        }), function (err) {
                        if (err.info instanceof service.vim.NotAuthenticated) {
                            cleanup();
                            deferred.reject(false);
                        }
                         else{
                            cleanup();
                            deferred.reject(false);
                        }
                    };
                }
                else{
                    cleanup();
                    deferred.reject(false);
                }
                return deferred.promise;
            },
            /**
             * logout
             */
            logout: function () {
                var deferred = $q.defer();
                if (cookie !== undefined && service !== undefined) {
                    service.vimPort.logout(service.serviceContent.sessionManager).then(function () {
                        cleanup();
                        console.log("logged out");
                        deferred.resolve();
                    }, function (err) {
                        console.log(err + " " + err.message);
                        cleanup();
                        deferred.reject(err);
                    });
                }
                else {
                    cleanup();
                    deferred.resolve();
                }
                return deferred.promise;
            },
            /**
             * Get info from host
             */
            getHostInfo: function(){
                var deferred = $q.defer();
                if (cookie !== undefined && service !== undefined) {
                    var propertyCollector = service.serviceContent.propertyCollector;
                    var rootFolder = service.serviceContent.rootFolder;
                    var viewManager = service.serviceContent.viewManager;
                    var type = "ManagedEntity";
                    service.vimPort.createContainerView(viewManager, rootFolder,
                        [type], true).then(function(containerView) {
                        return service.vimPort.retrievePropertiesEx(propertyCollector, [
                            service.vim.PropertyFilterSpec({
                                objectSet : service.vim.ObjectSpec({
                                    obj: containerView,
                                    skip: true,
                                    selectSet: service.vim.TraversalSpec({
                                        path: "view",
                                        type: "ContainerView"
                                    })
                                }),
                                propSet: service.vim.PropertySpec({
                                    type: type,
                                    pathSet: ["name"]
                                })
                            })
                        ], service.vim.RetrieveOptions());
                    }).then(function(result) {
                        var data = result.objects;
                        deferred.resolve(data);
                    });
                }
                else{
                    deferred.reject(null);
                }
                return deferred.promise;
            },
            /**
             * Enable SSH
             */
            enableSSHonHost: function(){
                var deferred = $q.defer();
                if (cookie !== undefined && service !== undefined) {
                    var propertyCollector = service.serviceContent.propertyCollector;
                    var rootFolder = service.serviceContent.rootFolder;
                    var viewManager = service.serviceContent.viewManager;
                    return service.vimPort.createContainerView(viewManager, rootFolder,
                        ["HostSystem"], true).then(function(containerView) {
                        return service.vimPort.retrievePropertiesEx(propertyCollector, [
                            service.vim.PropertyFilterSpec({
                                objectSet: service.vim.ObjectSpec({
                                    obj: containerView,
                                    skip: true,
                                    selectSet: service.vim.TraversalSpec({
                                        path: "view",
                                        type: "ContainerView"
                                    })
                                }),
                                propSet: service.vim.PropertySpec({
                                    type: "HostSystem",
                                    pathSet: ["configManager"]
                                })
                            })
                        ], service.vim.RetrieveOptions()).then(function (result) {
                            var hostServiceSystem = result.objects[0].propSet[0].val.serviceSystem;
                            return service.vimPort.startService(hostServiceSystem, "TSM-SSH");
                        });
                    });
                    }
                else{
                    deferred.reject(false);
                }
                return deferred.promise;
            },
            /**
             * Disable SSH
             */
            disableSSHonHost: function(){
                var deferred = $q.defer();
                if (cookie !== undefined && service !== undefined) {
                    var propertyCollector = service.serviceContent.propertyCollector;
                    var rootFolder = service.serviceContent.rootFolder;
                    var viewManager = service.serviceContent.viewManager;
                    return service.vimPort.createContainerView(viewManager, rootFolder,
                        ["HostSystem"], true).then(function(containerView) {
                        return service.vimPort.retrievePropertiesEx(propertyCollector, [
                            service.vim.PropertyFilterSpec({
                                objectSet: service.vim.ObjectSpec({
                                    obj: containerView,
                                    skip: true,
                                    selectSet: service.vim.TraversalSpec({
                                        path: "view",
                                        type: "ContainerView"
                                    })
                                }),
                                propSet: service.vim.PropertySpec({
                                    type: "HostSystem",
                                    pathSet: ["configManager"]
                                })
                            })
                        ], service.vim.RetrieveOptions()).then(function (result) {
                            var hostServiceSystem = result.objects[0].propSet[0].val.serviceSystem;
                            return service.vimPort.sopService(hostServiceSystem, "TSM-SSH");
                        });
                    });
                }
                else{
                    deferred.reject(false);
                }
                return deferred.promise;
            }
        }
    }
})();


