/**
 * Created by ahaq on 7/24/2016.
 */

angular
    .module('dashboard')
    .controller('loginController', [
        'vsphereService', '$location',
        LoginController
    ]);

/**
 * Controller for the loging in
 * @param vsphereService
 * @param $location
 * @constructor
 */
function LoginController( vsphereService, $location ) {
    var self = this;

    self.hostname = null;
    self.username = null;
    self.password = null;
    self.loginToHost   = loginToHost;

    /**
     * Login to host
     */
    function loginToHost () {
        if(self.hostname &&  self.username && self.password &&
            self.hostname !== '' &&  self.username !== '' && self.password !== '' ) {
            vsphereService.
            login(self.hostname, self.username, self.password)
                .then(function (result) {
                        $location.url('/');
                    });
        }
    }
};