/**
 * Created by ahaq on 8/1/2016.
 */
(function(){

    angular
        .module('dashboard')
        .controller('hostController', [
            'vsphereService',
            HostController
        ]);

    /**
     * Controller for displaying host related info
     * @param vsphereService
     * @constructor
     */
    function HostController(vsphereService) {
        var self = this;

        self.enableSSH = enableSSH;
        self.sshEnabled = false;

        /**
         * Enable/Disable SSH
         */
        function enableSSH(){
            if (!self.sshEnabled) {
                vsphereService.enableSSHonHost()
                    .then(function () {
                        },
                        function (err) {
                        });
            }
            else{
                vsphereService.disableSSHonHost()
                    .then( function() {
                        },
                        function(err) {
                        });
            }
        }
    }
})();