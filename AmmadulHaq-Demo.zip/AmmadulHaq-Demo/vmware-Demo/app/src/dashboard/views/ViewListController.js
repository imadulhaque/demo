/**
 * Created by ahaq on 7/28/2016.
 */
(function(){

    angular
        .module('dashboard')
        .controller('viewListController', [
            '$state' ,'$stateParams',
            ViewListController
        ]);

    /**
     * Main Controller for the Angular Material Starter App
     * @param $scope
     * @param $mdSidenav
     * @param avatarsService
     * @constructor
     */
    function ViewListController($state, $stateParams) {
        var self = this;
        var prevState = $stateParams.previousState;
        self.title = $stateParams.data.title;
        self.items = $stateParams.data.list;
        self.close = close;
        
        function close(){
            $state.go(prevState);
        }
    }
})();