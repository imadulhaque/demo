(function(){
  'use strict';

  angular.module('dashboard')
         .service('dashboardService', ['$q',  DashboardService]);

  /**
   * @returns {{loadMenus: Function}}
   * @constructor
   */
  function DashboardService($q){
    var mainMenus =  [{key:'roles', title: 'Roles', image: 'person'},
      {key:'clientSettings', title: 'Client Settings', image: 'settings'}];
    // Promise-based API
    return {
      loadMenus : function() {
        return $q.when(mainMenus);
      }
    };
  }

})();
