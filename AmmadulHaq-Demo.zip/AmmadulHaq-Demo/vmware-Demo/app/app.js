/**
 * Created by ahaq on 7/22/2016.
 */
angular
    .module('vmwareApp', ['ngMaterial', 'ui.router', 'ngCookies', 'ng-mfb', 'dashboard' ])
    .config(function($mdThemingProvider, $mdIconProvider, $stateProvider, $urlRouterProvider){

        $mdIconProvider
            .defaultIconSet("./assets/svg/avatars.svg", 128);

        $mdThemingProvider.theme('default')
            .primaryPalette('blue')
            .accentPalette('blue');

        // *********************************
        // Internal methods
        // *********************************
        /**
         * Check if user is logged in or not
         */
        var checkLoggedIn = function ($q, $location, vsphereService) {
            var deferred = $q.defer();
            // check if user is logged in
            vsphereService
                .loggedin()
                .then( function(result) {
                    if (!result){
                        $location.url('/login');
                    }
                    deferred.resolve(true);
                },
                function(err){
                    $location.url('/login');
                    deferred.resolve(true);
                });
            return deferred.promise;
        };

        $urlRouterProvider.otherwise('/');

        $stateProvider
            .state('home', {
                url: '/',
                templateUrl: 'src/dashboard.html',
                controller: 'dashboardController',
                controllerAs: 'dCtrl',
                resolve: {
                    loggedin: checkLoggedIn
                }
            })
            .state('home.host', {
                url: '/vms',
                templateUrl: 'src/dashboard/views/host.html',
                controller: 'hostController',
                controllerAs: 'hCtrl',
                params: {previousState: null, data: null},
                resolve: {
                    loggedin: checkLoggedIn
                }
            })
            .state('home.vms', {
                url: '/vms',
                templateUrl: 'src/dashboard/views/viewList.html',
                controller: 'viewListController',
                controllerAs: 'vlCtrl',
                params: {previousState: null, data: null},
                resolve: {
                    loggedin: checkLoggedIn
                }
            })
            .state('home.datastores', {
                url: '/datastores',
                templateUrl: 'src/dashboard/views/viewList.html',
                controller: 'viewListController',
                controllerAs: 'vlCtrl',
                params: {previousState: null, data: null},
                resolve: {
                    loggedin: checkLoggedIn
                }
            })
            .state('home.resourcePools', {
                url: '/resourcepools',
                templateUrl: 'src/dashboard/views/viewList.html',
                controller: 'viewListController',
                controllerAs: 'vlCtrl',
                params: {previousState: null, data: null},
                resolve: {
                    loggedin: checkLoggedIn
                }
            })
            .state('login', {
                url: '/login',
                templateUrl: 'login.html',
                controller: 'loginController',
                controllerAs: 'lCtrl',
                resolve: {
                    loggedin: checkLoggedIn
                }
            });
    });